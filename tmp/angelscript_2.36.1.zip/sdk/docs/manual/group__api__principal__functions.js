var group__api__principal__functions =
[
    [ "asCreateScriptEngine", "group__api__principal__functions.html#ga030e559c6ec9e2ee0be5836b84061bac", null ],
    [ "asGetActiveContext", "group__api__principal__functions.html#gaf8b78824db10b0f757990805a4e18f70", null ],
    [ "asGetTypeTraits", "group__api__principal__functions.html#ga863f2a1e60e6c19eea9c6b34690dcc00", null ]
];