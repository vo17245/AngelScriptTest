var searchData=
[
  ['jit_20compilation_0',['JIT compilation',['../doc_adv_jit_topic.html',1,'doc_advanced']]]
];
