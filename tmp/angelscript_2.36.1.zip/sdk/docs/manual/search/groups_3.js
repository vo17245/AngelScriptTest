var searchData=
[
  ['secondary_20interfaces_0',['Secondary interfaces',['../group__api__secondary__interfaces.html',1,'']]]
];
