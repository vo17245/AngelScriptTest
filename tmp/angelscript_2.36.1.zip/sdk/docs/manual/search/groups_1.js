var searchData=
[
  ['memory_20functions_0',['Memory functions',['../group__api__memory__functions.html',1,'']]],
  ['multi_2dthread_20support_20functions_1',['Multi-thread support functions',['../group__api__multithread__functions.html',1,'']]]
];
