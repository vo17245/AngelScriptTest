var searchData=
[
  ['license_0',['License',['../doc_license.html',1,'main_topics']]]
];
