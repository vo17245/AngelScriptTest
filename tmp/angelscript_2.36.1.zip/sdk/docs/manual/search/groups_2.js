var searchData=
[
  ['principal_20functions_0',['Principal functions',['../group__api__principal__functions.html',1,'']]],
  ['principal_20interfaces_1',['Principal interfaces',['../group__api__principal__interfaces.html',1,'']]]
];
